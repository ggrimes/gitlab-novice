#!/usr/bin/env python
"""Filter variants by quality and summarise them."""
import pandas as pd
import matplotlib.pyplot as plt

variants = pd.read_csv("data.csv")
variants = variants[variants.QUAL > 30]

variants.to_csv("results.csv", index=False)

fig, ax = plt.subplots()
ax.hist(variants.QUAL, bins=10)
ax.set_xlabel("Variant quality (QUAL)")
plt.savefig("figure3.png")
